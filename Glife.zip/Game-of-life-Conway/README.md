# Game-of-life-Conway
O objetivo deste trabalho é implementar um sistema que realize a simulação do jogo da vida de Conway
